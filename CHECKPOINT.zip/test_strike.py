import asyncio
import sys
import time

sys.path.insert(0, '.')
from bot.chainlink import chainlink_fetcher
from bot.settlement import mark_window_open_with_recovery

async def test():
    now_ms = time.time() * 1000
    window_ms = 15 * 60 * 1000
    start_ms = int((now_ms // window_ms) * window_ms)
    print("Window start UTC:", time.strftime('%H:%M:%S', time.gmtime(start_ms/1000)))
    t0 = time.time()
    win = await mark_window_open_with_recovery(
        start_ms=start_ms, window_ms=window_ms,
        current_price=77000.0, spot_price=76990.0, price_source='test', klines_5m=[])
    t1 = time.time()
    print(f"First call {t1-t0:.2f}s")
    print(f"  chainlink strike: {win['chainlink']}")
    print(f"  source:           {win.get('strike_source')}")
    print(f"  round_id:         {win.get('strike_round_id')}")
    print(f"  binance ref:      {win['binance']}")

    # Second call with completely different WS price — must return same cached strike
    t2 = time.time()
    win2 = await mark_window_open_with_recovery(
        start_ms=start_ms, window_ms=window_ms,
        current_price=99999.0, spot_price=0.0, price_source='test', klines_5m=[])
    t3 = time.time()
    print(f"Second call (cached) {(t3-t2)*1000:.0f}ms: chainlink={win2['chainlink']}")

    assert win2['chainlink'] == win['chainlink'], "FAIL: cache broken!"
    assert win['chainlink'] is not None, "FAIL: no strike returned!"
    print("PASS: strike is on-chain, stable, and cached per-window")

asyncio.run(test())
